# c2js Generator

Note: make sure emscripten sdk is installed into this directory as "./emsdk"

http://kripken.github.io/emscripten-site/docs/getting_started/downloads.html