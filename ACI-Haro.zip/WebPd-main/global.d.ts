declare module '*.asc' {
    const content: string
    export default content
}

declare module '*.generated.js.txt' {
    const content: string
    export default content
}

declare module 'assemblyscript/asc'

declare module 'assemblyscript/dist/asc.js'