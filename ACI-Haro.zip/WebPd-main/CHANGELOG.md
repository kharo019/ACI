0.4.2
------

- objects `[swap]`, `[min]`, `[max]`, `[atan2]`, `[wrap]`, `[rmstodb]`, `[dbtorms]`, `[powtodb]`, `[dbtopow]`, `[ftom]`, `[clip]`
- fix bug with zeros in `[/]` and `[%]`
- support for comma separated messages


0.4.1
------

- object `[adc~]`


0.4.0
======

- public API to create externals
- bug fixes


0.3.2
-------

- objects `[until]`, `[cos]`, `[sin]`, `[tan]`, `[atan]`, `[log]`, `[exp]`, `[sqrt]`, `[abs]`


0.3.1
-------

- bug fixes
- object `[int]`


0.3.0
======

- Complete refactor to Web Audio API


0.2.3
------

- objects `[pack]`, `[sig~]`


0.2.2
------

- objects `[hip~]`, `[lop~]`, `[delread~]`, `[delwrite~]`, `[clip~]`
- abbreviations for object names and object arguments


0.2.1
------

- added `Pd.isSupported` method to test browser support
- objects `[tabread4~]`, `[phasor~]`, `[timer]`, `[moses]`
- changed build system to [grunt](https://github.com/gruntjs/grunt)
- changed event management to [EventEmitter2](https://github.com/hij1nx/EventEmitter2)

