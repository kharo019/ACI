## Instructions for Ubuntu 15.10
---

Install cross-compiler tools

`$ sudo apt-get install gcc-arm-linux-gnueabihf`

`$ sudo apt-get install g++-arm-linux-gnueabihf`

That's it...
